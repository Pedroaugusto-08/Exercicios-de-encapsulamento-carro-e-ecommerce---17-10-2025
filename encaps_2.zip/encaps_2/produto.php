<?php
class Produto
{
    private string $nome;
    private float $preco;
    private int $estoque = 0;


    public function __construct(string $nome, float $preco, int $estoque)
    {
        $this->nome = $nome;
        $this->preco = round($preco, 2);
        $this->estoque = $estoque;
    }

    public function getNome(): string
    {
        $nome = trim($this->nome);
        if($this->nome == '' || $this->nome == null){
            return "Sem nome do pedido";
        } elseif (is_numeric($this->nome)){
            return "O nome so pode conter letras";
        } else{
        return $this->nome;
        }
    }

    public function getPreco(): float
    {       if(is_string($this->preco)){
            return "O preço so pode conter números";
        } elseif ($this->preco < 0){
            return "O preço deve ser positivo";
        } else{
            round($this->preco, 2);
            return $this->preco;
        }
    }

    public function getEstoque(): int
    {
        if($this->estoque < 0){
            return "O estoque não pode ser negativo";
        } elseif (is_string($this->estoque)){
            return "O estoque so pode conter números";
        } else{
            round($this->estoque, 2);
            return $this->estoque;
        }
    }

    public function atualizarPreco(float $novoPreco): void
    {
        if($novoPreco > 0){
            $this->preco = round($novoPreco, 2);
        }
    }

    public function vender(int $qtd): float
    {
        if($qtd > 0){
            $this->estoque -= $qtd;
            $subtotal = round($this->preco * $qtd, 2);
            return $subtotal;
        } 
        
    }

    public function repor(int $novoEstoque): void
    {
        if ($novoEstoque < 0){
            $this->estoque += $novoEstoque;
        }
    }

    public function exibirProduto(): string
    {
        return "{$this->nome}: {$this->preco} reais (Estoque: {$this->estoque})<br>";
    }
}
?>