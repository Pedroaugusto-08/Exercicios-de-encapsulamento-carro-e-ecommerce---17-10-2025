<?php
class Carro 
{
    private string $marca;
    private string $modelo;
    private int $ano;

    public function __construct(string $marca, string $modelo, int $ano)
    {
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->ano = $ano;
    }

    public function getMarca(): string
    {
        if($this->marca == null){
            return "Marca inválida";
        } elseif(is_numeric($this->marca)){
            return "Marca inválida"; 
        } else{
            return $this->marca;
        }
    }

    public function getModelo(): string
    {
        if($this->modelo == null){
            return "Modelo inválido";
        } else{
            return $this->modelo; 
        }
    }

    public function getAno(): int|string 
    {  
        if($this->ano == null){
            return "Ano inválido";
        } elseif($this->ano < 1886){
            return "Ano inválido";
        } elseif($this->ano > (date('Y') + 1)){
            return "Ano inválido";
        } elseif(is_string($this->ano)){
            return "Ano inválido";
        } else{
            return $this->ano;
        }
    }

    public function alterarMarca(string $novaMarca): void
    {
        $this->marca = $novaMarca;
    }

    public function alterarModelo(string $novaModelo): void
    {
        $this->modelo = $novoModelo;
    }

    public function alterarAno(int $novoAno): void
    {
        $this->ano = $novoAno;
    }

    public function getMarca2(): string
    {
        return $this->marca;
    }

    public function getModelo2(): string
    {
        return $this->modelo;
    }

    public function getAno2(): int
    {
        return $this->ano;
    }

    public function ficha()
    {
        return "marca: " . $this->getMarca() . "<br>" . "modelo: " . $this->getModelo() . "<br>" . "ano: " . $this->getAno();
    }

    public function ficha2()
    {
        return "marca: " . $this->getMarca2() . "<br>" . "modelo: " . $this->getModelo2() . "<br>" . "ano: " . $this->getAno2();
    }
}
?>