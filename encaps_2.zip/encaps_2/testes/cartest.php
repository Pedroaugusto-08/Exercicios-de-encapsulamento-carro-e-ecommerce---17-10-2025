<?php
require'../carro.php';
$car1 = new Carro ("Ford", "Fusion", 2015);
echo " Carro1: <br>{$car1->ficha()} <br> <br>";
$car1->alterarAno(2018);
echo "--ficha alterada-- <br> {$car1->ficha2()} <br> <hr>";

$car2 = new Carro ("", "Hrv", 2027);
echo "Carro2: <br> {$car2->ficha()} <br> <br>";
$car2->alterarMarca("Honda");
$car2->alterarAno(2022);
echo "--ficha alterada-- <br> {$car2->ficha2()}";
