<?php
require '../produto.php';
require '../pedido.php';

$produto1 = new Produto("Teclado", 120.00, 10);
$produto2 = new Produto("Mouse", 52.25, 250);
$produto3 = new Produto("Mouse Pad", 50.00, 500);
$produto4 = new Produto("Monitor", 300.50, 100);

echo $produto1->exibirProduto();
echo $produto2->exibirProduto();
echo $produto3->exibirProduto();
echo $produto4->exibirProduto();

$pedido1 = new Pedido("P-001");
$pedido1->adicionarItem($produto4, 10);
$pedido1->adicionarItem($produto2, 4);

echo $pedido1->exibirResumo() . "<br>";
echo $produto1->exibirProduto();
echo $produto2->exibirProduto();
echo $produto3->exibirProduto();
echo $produto4->exibirProduto();

$pedido1->removerItem("Teclado");
echo $pedido1->exibirResumo() . "<br>";
echo $produto1->exibirProduto();
echo $produto2->exibirProduto();
echo $produto3->exibirProduto();
echo $produto4->exibirProduto();

$produto3->atualizarPreco(77.99);
echo $pedido1->exibirResumo() . "<br>";
echo $produto1->exibirProduto();
echo $produto2->exibirProduto();
echo $produto3->exibirProduto();
echo $produto4->exibirProduto();
?>