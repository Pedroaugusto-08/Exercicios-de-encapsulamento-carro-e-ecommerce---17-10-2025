<?php
require_once 'produto.php';

class Pedido 
{
    private string $numeroPedido;
    private array $itens = [];
    private float $valorTotal;

    public function __construct(string $numeroPedido)
    {
        $this->numeroPedido = $numeroPedido;
    }

    public function adicionarItem(Produto $produto, int $qtd): void
    {
        if($qtd > 0) {
           foreach ($this->itens as &$item){
                if ($item ['produto']->getNome() === $produto->getNome()){
                    $item ['quantidade'] += $qtd;
                    return;
                }
            }

            $this->itens[] = ['produto' => $produto, 'quantidade' => $qtd];
        }
        $produto->vender($qtd);
    }

    public function removerItem(string $nomeProduto): bool
    {
        $novoItem = [];
        $itemRemovido = false;

        foreach($this->itens as $item){
            if($item ['produto']-> getNome() !== $nomeProduto){
               $novo[] = $item;
            } else{
                $itemRemovido = true;
            }
        }
        $this->itens = $novo;
        return $itemRemovido;
    }

    public function getNumeroPedido(): string
    {
        return $this->numeroPedido;
    }

    public function getItens(): array
    {
        return $this->Itens;
    }

    public function recalcularTotal():float 
    {
        $total = 0.0;
        foreach($this->itens as $item){
           $total += $item['produto']->getPreco() * $item['quantidade'];
        }
        return round($total, 2);
    }

    public function exibirResumo(): string 
    {
        $linhas = [];
        foreach ($this->itens as $item) {
            $nome = $item['produto']->getNome();
            $qtd = $item['quantidade'];
            $preco = round($item['produto']->getPreco(), 2);
            $subtotal = round($item['produto']->getPreco() * $qtd, 2);
            $linhas[] = "{$qtd} x {$nome}  R$ {$preco} = R$ {$subtotal}";
        }
        $total = round($this->recalcularTotal(), 2);
        $corpo = implode("<br>", $linhas);
        return "Número do pedido: {$this->numeroPedido}<br>{$corpo}<br>Total: R$ {$total}";
    }
}
?>